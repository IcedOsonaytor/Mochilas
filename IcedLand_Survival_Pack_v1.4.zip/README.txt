ICEDLAND Survival Pack v1.4

Incluye:
- IcedCoins
- Mochilas
- Sistema Glacial
- Set Congelado rediseñado (oscuro, runas y hielo)
- Espada Congelada rediseñada
- Armaduras térmicas
- Precipitación tipo ventisca

Requiere IcedLandGlacial v0.7.3 para corregir slots de armadura equipada.
