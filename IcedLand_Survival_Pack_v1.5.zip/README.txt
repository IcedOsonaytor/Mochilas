ICEDLAND Survival Pack v1.5

- Conserva IcedCoins y mochilas.
- Set Congelado más fino, oscuro y afilado.
- Espada Congelada más ancha y con más presencia.
- Armaduras térmicas: base del material + forro fino tipo borreguito.
- Forro térmico rediseñado.
- Conserva la ventisca del pack anterior.

Compatible con IcedLandGlacial v0.7.3. No requiere cambiar el plugin.
