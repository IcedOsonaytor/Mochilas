ICEDLAND Survival Pack v1.2

Incluye:
- 6 mochilas ICEDLAND
- 4 IcedCoins fisicos personalizados (1, 10, 100, 1000)
- Sistema Glacial: Fragmento, Lingote, Espada, Forro Termico y Set Congelado (iconos)

Compatibilidad:
- Minecraft Java / Paper 1.21.11
- IcedBackpackBridge v2+
- IcedSurvival v1.1.1+
- IcedLandGlacial v0.7.1+ para los modelos glaciales

Notas:
- Este ZIP reemplaza al pack anterior: sigue conteniendo mochilas y monedas.
- El Set Congelado ya tiene iconos custom en inventario. La textura 3D/puesta del armor se agregara en una siguiente fase del mismo pack.
- Usa el nuevo SHA-1 al actualizar la URL del resource pack.
