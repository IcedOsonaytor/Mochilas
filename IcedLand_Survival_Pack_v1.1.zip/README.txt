ICEDLAND Survival Pack v1.1
Incluye:
- 6 mochilas ICEDLAND (satchel, gold, diamond, sculk, netherite, dragon)
- 4 IcedCoins fisicos personalizados (1, 10, 100, 1000)
- Estilo ICEDLAND + vanilla mejorado

Uso:
- Reemplaza el pack anterior por este ZIP en el servidor.
- Usa el nuevo SHA-1 para server.properties o AMP.
- Requiere IcedBackpackBridge v2+ para mochilas y IcedSurvival v1.1.1+ para IcedCoins.
