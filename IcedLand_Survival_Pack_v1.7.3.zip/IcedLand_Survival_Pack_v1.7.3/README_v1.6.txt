ICEDLAND Survival Pack v1.6

Cambios visuales:
- Armaduras térmicas: mucho más finas.
- Casco térmico abierto para dejar visible la cara.
- El material base sigue siendo reconocible.
- Borreguito sólo en cuello/bordes/cuffs, no como bloques gruesos.
- Set Congelado: oscuro, cian, visor abierto y más cercano al estilo de referencia.
- Espada Congelada más gruesa y con mayor presencia.
- Conserva IcedCoins, mochilas, lluvia/ventisca y todos los assets anteriores.

Compatible con IcedLandGlacial v0.7.3.
No requiere cambiar el plugin ni ejecutar refresh si los items ya apuntan a los mismos modelos.
