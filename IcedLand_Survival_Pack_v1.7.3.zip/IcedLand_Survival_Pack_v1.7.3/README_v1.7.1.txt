ICEDLAND Survival Pack v1.7.1
- Conserva todos los assets de v1.7.
- Reduce fuertemente la densidad y opacidad de la precipitación.
- No cambia monedas, mochilas, armaduras ni modelos.
