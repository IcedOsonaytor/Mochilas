ICEDLAND Survival Pack v1.7

Diseños 100% originales de ICEDLAND:
- Armaduras térmicas inspiradas sólo en el estilo general de equipamiento detallado:
  cara abierta, silueta visual más limpia, material base reconocible y borreguito discreto.
- Armadura Congelada original inspirada en una estética cristalina/diamante,
  con azul oscuro, cian, visor abierto y detalles de hielo.
- Espada Congelada más grande y ancha; también aumenta su escala visual en mano.
- Mantiene IcedCoins, mochilas y todas las rutas/modelos de las versiones anteriores.

Compatible con IcedLandGlacial v0.7.3.
