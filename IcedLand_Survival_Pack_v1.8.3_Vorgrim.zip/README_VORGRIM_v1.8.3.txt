ICEDLAND VORGRIM v1.8.3
Nuevo sprite de la Reliquia ICED, y sonidos exclusivos summon/impact/hurt/death/wave.
Sonidos sintetizados originales de prueba (no grabaciones de voz).
Compatible con addon IcedLandVorgrimUpgrade 1.1.0-beta1.
No sustituye los sonidos globales del Iron Golem. El sonido vanilla puede seguir escuchandose.
