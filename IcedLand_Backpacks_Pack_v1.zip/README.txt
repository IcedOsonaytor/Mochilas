ICEDLAND Backpacks Pack v1

Minecraft Java: 1.21.11
Resource pack format: 75.0
Estilo: ICEDLAND + vanilla mejorado

Modelos:
- icedland:backpack/satchel
- icedland:backpack/gold
- icedland:backpack/diamond
- icedland:backpack/sculk
- icedland:backpack/netherite
- icedland:backpack/dragon

Este pack NO reemplaza los items vanilla. Requiere IcedBackpackBridge v2 para asignar minecraft:item_model a las mochilas de BackpackPlugin.

Para servidor, comprime el CONTENIDO del pack dejando pack.mcmeta en la raíz del ZIP (este ZIP ya viene correcto).
