ICEDLAND Survival Pack v1.3

Pack maestro único de ICEDLAND.
Incluye:
- Mochilas existentes
- IcedCoins existentes
- Fragmento, Lingote, Espada y Set Congelado
- Armaduras térmicas visuales: cuero, cobre, oro, hierro, diamante y netherite
- Modelos de armadura equipada mediante equipment assets (Java 1.21.11)
- Lluvia reemplazada visualmente por ventisca/nieve

IMPORTANTE:
Usar junto con IcedLandGlacial v0.7.2 y ejecutar /icedglacial refresh una vez para actualizar items antiguos.
