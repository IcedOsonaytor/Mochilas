ICEDLAND SURVIVAL PACK v1.8.1 — VORGRIM

Agrega modelos/texturas para:
- VORGRIM — Devorador de Escarcha
- Núcleo Glacial de ICED
- Reliquia de ICED — Aliento Invernal

Requiere el plugin IcedLandVorgrim-1.0.2.jar junto con IcedLandGlacial.
No requiere mods de cliente.

Ajuste v1.8.1: posición/escala de Vorgrim corregidas para ItemDisplay.
